import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:fundi/data/account_repository.dart';
import 'package:fundi/data/admin_repository.dart';
import 'package:fundi/data/provider_repository.dart';
import 'package:fundi/data/voice_recorder.dart';
import 'package:fundi/data/zones.dart';
import 'package:fundi/main.dart';
import 'package:fundi/models/service_provider.dart';
import 'package:fundi/state/app_state.dart';

void main() {
  final kasarani = zones.first;

  group('ranking', () {
    final repo = SampleProviderRepository();

    test(
      'nearby: really available first, then nearest; far ones excluded',
      () async {
        final list = await repo.nearby(lat: kasarani.lat, lng: kasarani.lng);
        expect(list, isNotEmpty);
        expect(list.first.availability, Availability.available);
        // Kilimani is ~13 km from Kasarani, outside the default 10 km.
        expect(list.any((p) => p.area == 'Kilimani'), isFalse);
        final ranks = list.map((p) => p.availability.index).toList();
        expect(ranks, [...ranks]..sort());
      },
    );

    test('bestMatches never offers a busy or offline provider', () async {
      final list = await repo.nearby(lat: kasarani.lat, lng: kasarani.lng);
      for (final mode in RequestMode.values) {
        for (final p in bestMatches(list, mode)) {
          expect(p.availability, isNot(Availability.busy));
          expect(p.availability, isNot(Availability.offline));
        }
      }
    });

    test(
      'come-to-me matches mobile mechanics; visit matches garages',
      () async {
        final list = await repo.nearby(lat: kasarani.lat, lng: kasarani.lng);
        expect(
          bestMatches(list, RequestMode.comeToMe).every((p) => p.isMobile),
          isTrue,
        );
        expect(
          bestMatches(list, RequestMode.visitGarage).every((p) => !p.isMobile),
          isTrue,
        );
      },
    );

    test('fromRow maps a database row, including stale availability', () {
      final p = ServiceProvider.fromRow({
        'id': 'x',
        'type': 'garage',
        'display_name': 'G',
        'business_phone': '+254700000000',
        'area': 'A',
        'lat': -1.2,
        'lng': 36.8,
        'distance_km': 1.3,
        'availability': 'unconfirmed',
        'checks_passed': ['identity', 'business'],
        'callout_fee_kes': 300,
        'makes': <dynamic>[],
        'rating_avg': 4.5,
        'rating_count': 10,
        'service_radius_km': 0,
      });
      expect(p.type, ProviderType.garage);
      expect(p.availability, Availability.unconfirmed);
      expect(p.checksPassed, {CheckKind.identity, CheckKind.business});
    });
  });

  group('owner journeys', () {
    late SampleProviderRepository repo;
    late SampleAccountRepository account;
    late List<String> dialed;

    Future<void> pumpApp(WidgetTester tester) async {
      repo = SampleProviderRepository();
      account = SampleAccountRepository();
      dialed = [];
      tester.view.physicalSize = const Size(1080, 2340);
      tester.view.devicePixelRatio = 2.75;
      addTearDown(tester.view.reset);
      await tester.pumpWidget(
        ProviderScope(
          overrides: [
            repositoryProvider.overrideWithValue(repo),
            accountProvider.overrideWithValue(account),
            voiceRecorderProvider.overrideWithValue(_FakeRecorder()),
            photoPickerProvider.overrideWithValue(
              ({required bool camera}) async =>
                  (bytes: Uint8List.fromList([1, 2, 3]), mime: 'image/jpeg'),
            ),
            gpsLookupProvider.overrideWithValue(() async => null),
            dialerProvider.overrideWithValue((phone) async {
              dialed.add(phone);
              return true;
            }),
          ],
          child: const FundiApp(),
        ),
      );
      await tester.pumpAndSettle();
    }

    testWidgets('home shows the two actions and no login', (tester) async {
      await pumpApp(tester);
      expect(find.text('Find me a mechanic'), findsOneWidget);
      expect(find.text('Browse and call'), findsOneWidget);
      expect(find.textContaining('Sign in'), findsNothing);
    });

    testWidgets('browse then call: two taps open the dialer and log the tap', (
      tester,
    ) async {
      await pumpApp(tester);
      await tester.tap(find.byKey(const Key('home-browse')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('call-s1')));
      await tester.pump();
      expect(dialed, ['+254700000001']);
      expect(repo.loggedContacts.single.kind, ContactKind.callTap);
      expect(
        find.textContaining('Did Otieno Mobile Mechanic help?'),
        findsOneWidget,
      );
    });

    testWidgets('find me: no category needed, returns a best match', (
      tester,
    ) async {
      await pumpApp(tester);
      await tester.tap(find.byKey(const Key('home-find')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('find-submit')));
      await tester.pumpAndSettle();
      expect(find.text('Your best match'), findsOneWidget);
      expect(find.text('Otieno Mobile Mechanic'), findsOneWidget);
      expect(repo.requests, [RequestMode.comeToMe]);
    });

    testWidgets('find me: a photo and a voice note travel with the request', (
      tester,
    ) async {
      await pumpApp(tester);
      await tester.tap(find.byKey(const Key('home-find')));
      await tester.pumpAndSettle();

      await tester.tap(find.byKey(const Key('add-voice')));
      await tester.pump();
      expect(find.textContaining('Stop ('), findsOneWidget);
      await tester.tap(find.byKey(const Key('add-voice')));
      await tester.pump();
      expect(find.text('Voice note added'), findsOneWidget);

      await tester.tap(find.byKey(const Key('add-photo')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('photo-camera')));
      await tester.pumpAndSettle();
      expect(find.text('Photo added'), findsOneWidget);

      await tester.scrollUntilVisible(
        find.byKey(const Key('find-submit')),
        200,
        scrollable: find.byType(Scrollable).last,
      );
      await tester.tap(find.byKey(const Key('find-submit')));
      await tester.pumpAndSettle();
      expect(find.text('Your best match'), findsOneWidget);
      expect(repo.lastAttachments, (photo: true, voice: true));
    });

    testWidgets('stale availability is never shown as available', (
      tester,
    ) async {
      await pumpApp(tester);
      await tester.tap(find.byKey(const Key('home-browse')));
      await tester.pumpAndSettle();
      await tester.scrollUntilVisible(
        find.text('Wanjiru Auto Electrics'),
        200,
        scrollable: find.byType(Scrollable).last,
      );
      expect(find.text('Availability not confirmed'), findsOneWidget);
    });

    testWidgets('mechanic: sign in, apply, then switch to available', (
      tester,
    ) async {
      await pumpApp(tester);
      await tester.tap(find.byKey(const Key('home-provider')));
      await tester.pumpAndSettle();

      // A bad number is rejected before any code is sent.
      await tester.enterText(find.byKey(const Key('phone')), '12345');
      await tester.tap(find.byKey(const Key('send-code')));
      await tester.pumpAndSettle();
      expect(
        find.textContaining('Enter a Kenyan mobile number'),
        findsOneWidget,
      );

      await tester.enterText(find.byKey(const Key('phone')), '0712 345 678');
      await tester.tap(find.byKey(const Key('send-code')));
      await tester.pumpAndSettle();
      expect(find.textContaining('+254712345678'), findsOneWidget);

      await tester.enterText(find.byKey(const Key('code')), '000000');
      await tester.tap(find.byKey(const Key('verify-code')));
      await tester.pumpAndSettle();
      expect(find.text('That code is not correct.'), findsOneWidget);

      await tester.enterText(find.byKey(const Key('code')), '123456');
      await tester.tap(find.byKey(const Key('verify-code')));
      await tester.pumpAndSettle();

      await tester.enterText(
        find.byKey(const Key('listing-name')),
        'Baraka Mobile Mechanic',
      );
      await tester.enterText(
        find.byKey(const Key('listing-phone')),
        '0722000111',
      );
      await tester.enterText(find.byKey(const Key('listing-fee')), '400');
      await tester.scrollUntilVisible(
        find.byKey(const Key('listing-submit')),
        200,
        scrollable: find.byType(Scrollable).last,
      );
      await tester.tap(find.byKey(const Key('listing-submit')));
      await tester.pumpAndSettle();

      final sent = account.lastApplication!;
      expect(sent.businessPhone, '+254722000111');
      expect(sent.calloutFeeKes, 400);
      expect(sent.area, zones.first.name);

      // Pending until both required documents are uploaded.
      expect(find.text('One more step: your documents'), findsOneWidget);
      expect(find.text('Are you taking jobs now?'), findsNothing);
      for (final kind in ['national_id', 'selfie']) {
        await tester.tap(find.byKey(Key('upload-$kind')));
        await tester.pumpAndSettle();
        await tester.tap(find.byKey(const Key('doc-camera')));
        await tester.pumpAndSettle();
      }

      expect(find.text('Are you taking jobs now?'), findsOneWidget);
      expect(find.text('Owners see you as offline.'), findsOneWidget);
      await tester.tap(find.byKey(const Key('set-available')));
      await tester.pumpAndSettle();
      expect(find.textContaining('available until'), findsOneWidget);
    });
  });

  test('admin: cannot approve before identity is checked', () async {
    final admin = SampleAdminRepository();
    var waiting = await admin.listings(ListingStatus.pending);
    final first = waiting.firstWhere((l) => !l.canApprove);
    expect(
      () => admin.setStatus(first.id, ListingStatus.approved),
      throwsA(isA<AccountException>()),
    );
    await admin.setCheck(first.id, CheckKind.identity, true);
    await admin.setStatus(first.id, ListingStatus.approved);
    waiting = await admin.listings(ListingStatus.pending);
    expect(waiting.any((l) => l.id == first.id), isFalse);
    expect((await admin.listings(ListingStatus.approved)).single.id, first.id);
  });

  testWidgets(
    'admin console: tick identity, approve, listing leaves the queue',
    (tester) async {
      final account = SampleAccountRepository();
      await account.verifyCode(
        SampleAccountRepository.adminPhone,
        SampleAccountRepository.sampleCode,
      );
      tester.view.physicalSize = const Size(1080, 2340);
      tester.view.devicePixelRatio = 2.75;
      addTearDown(tester.view.reset);
      await tester.pumpWidget(
        ProviderScope(
          overrides: [
            accountProvider.overrideWithValue(account),
            gpsLookupProvider.overrideWithValue(() async => null),
          ],
          child: const FundiApp(),
        ),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('home-provider')));
      await tester.pumpAndSettle();
      expect(find.text('Verification'), findsOneWidget);
      expect(find.text('Mwangi Mobile Mechanic'), findsOneWidget);
      await tester.tap(find.byKey(const Key('check-p1-identity')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('approve-p1')));
      await tester.pumpAndSettle();
      expect(find.text('Mwangi Mobile Mechanic'), findsNothing);
    },
  );

  test('normalizeKenyanPhone accepts common formats and rejects others', () {
    expect(normalizeKenyanPhone('0712 345 678'), '+254712345678');
    expect(normalizeKenyanPhone('712345678'), '+254712345678');
    expect(normalizeKenyanPhone('+254 112 345 678'), '+254112345678');
    expect(normalizeKenyanPhone('254712345678'), '+254712345678');
    expect(normalizeKenyanPhone('0812345678'), isNull);
    expect(normalizeKenyanPhone('07123'), isNull);
    expect(normalizeKenyanPhone(''), isNull);
  });
}

class _FakeRecorder implements VoiceRecorder {
  @override
  Future<bool> start() async => true;

  @override
  Future<Recording?> stop() async =>
      (bytes: Uint8List.fromList([9, 9]), mime: 'audio/mp4');

  @override
  Future<void> cancel() async {}
}
